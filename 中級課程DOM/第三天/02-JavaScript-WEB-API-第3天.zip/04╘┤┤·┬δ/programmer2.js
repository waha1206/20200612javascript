/**
 * Created by Administrator on 2017-09-18.
 */
my$("btn").onclick=function () {
    console.log("助教好帅哦");
};