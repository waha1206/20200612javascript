/**
 * Created by Administrator on 2017-09-18.
 */
my$("btn").onclick=function () {
    console.log("小苏好帅哦");
};